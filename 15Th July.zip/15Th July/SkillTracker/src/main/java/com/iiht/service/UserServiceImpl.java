package com.iiht.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.iiht.dao.UserDao;
import com.iiht.exception.ResourceNotFoundException;
import com.iiht.model.User;
import com.iiht.model.Skill;

@Service("userService")
@Transactional(propagation= Propagation.REQUIRED)
@EnableTransactionManagement
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	public boolean saveUser(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	public Map<User, Skill> searchByUserName(String name) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean userAllotment(String user) {
		// TODO Auto-generated method stub
		return false;
	}

}
