package com.iiht.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.iiht.dao.SkillDao;
import com.iiht.model.User;
import com.iiht.model.Skill;

@Service("multiplexService")
@Transactional(propagation= Propagation.REQUIRED)
@EnableTransactionManagement
public class SkillServiceImpl implements SkillService {

	@Autowired
	private SkillDao multiplexDao;
	
	public boolean saveMultiplex(Skill multiplex) {
		// TODO Auto-generated method stub
		return false;
	}

	public Map<Skill, User> searchByMultiplexName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
