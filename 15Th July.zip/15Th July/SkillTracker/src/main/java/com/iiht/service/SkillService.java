package com.iiht.service;

import java.util.Map;

import com.iiht.model.User;
import com.iiht.model.Skill;

public interface SkillService {

	public boolean saveMultiplex(Skill multiplex);
	public Map<Skill,User> searchByMultiplexName(String name);
}
