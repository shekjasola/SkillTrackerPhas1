package com.iiht.dao;

import java.util.Map;

import com.iiht.exception.ResourceNotFoundException;
import com.iiht.model.User;
import com.iiht.model.Skill;

public interface UserDao {

	public boolean saveUser(User user);
	public Map<User,Skill> searchByUserName(String name) throws ResourceNotFoundException;
	public boolean userAllotment(String user);
}
