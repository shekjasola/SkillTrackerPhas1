package com.iiht.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;


@Entity
@Data
@Table(name = "SkillMaster")
public class Skill {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	@Column(name = "SkillId")
	private int skillId;
	@Column(name = "MinValue")
	private String minValue;

	@Column(name = "MaxValue")
	private String maxValue;

	@Column(name = "State")
	private String state;

	@Column(name = "BegainLevelMinValue")
	private String begainLevelMinValue;

	@Column(name = "BegainLevelMaxValue")
	private String begainLevelMaxValue;

	@Column(name = "IntermediateLevelMinValue")
	private String intermediateLevelMinValue;

	@Column(name = "IntermediateLevelMaxValue")
	private String intermediateLevelMaxValue;

	@Column(name = "ExpertLevelMinValue")
	private String expertLevelMinValue;

	@Column(name = "ExpertLevelMaxValue")
	private String expertLevelMaxValue;

	@Column(name = "Remarks")
	private String remarks;
	
	@Column(name = "Category")
	private String category;
	
	@Column(name = "Type")
	private String type;
	
	@ManyToOne
	@JoinColumn(name="UserId", nullable=false)
    private User user;
	
	/*
	 * public int getSkillId() { return skillId; }
	 * 
	 * public void setSkillId(int skillId) { this.skillId = skillId; }
	 * 
	 * public String getMinValue() { return minValue; }
	 * 
	 * public void setMinValue(String minValue) { this.minValue = minValue; }
	 * 
	 * public String getMaxValue() { return maxValue; }
	 * 
	 * public void setMaxValue(String maxValue) { this.maxValue = maxValue; }
	 * 
	 * 
	 * public String getBegainLevelMinValue() { return begainLevelMinValue; }
	 * 
	 * public void setBegainLevelMinValue(String begainLevelMinValue) {
	 * this.begainLevelMinValue = begainLevelMinValue; }
	 * 
	 * public String getBegainLevelMaxValue() { return begainLevelMaxValue; }
	 * 
	 * public void setBegainLevelMaxValue(String begainLevelMaxValue) {
	 * this.begainLevelMaxValue = begainLevelMaxValue; }
	 * 
	 * public String getIntermediateLevelMinValue() { return
	 * intermediateLevelMinValue; }
	 * 
	 * public void setIntermediateLevelMinValue(String intermediateLevelMinValue) {
	 * this.intermediateLevelMinValue = intermediateLevelMinValue; }
	 * 
	 * public String getIntermediateLevelMaxValue() { return
	 * intermediateLevelMaxValue; }
	 * 
	 * public void setIntermediateLevelMaxValue(String intermediateLevelMaxValue) {
	 * this.intermediateLevelMaxValue = intermediateLevelMaxValue; }
	 * 
	 * public String getExpertLevelMinValue() { return expertLevelMinValue; }
	 * 
	 * public void setExpertLevelMinValue(String expertLevelMinValue) {
	 * this.expertLevelMinValue = expertLevelMinValue; }
	 * 
	 * public String getExpertLevelMaxValue() { return expertLevelMaxValue; }
	 * 
	 * public void setExpertLevelMaxValue(String expertLevelMaxValue) {
	 * this.expertLevelMaxValue = expertLevelMaxValue; }
	 * 
	 * public String getRemarks() { return remarks; }
	 * 
	 * public void setRemarks(String remarks) { this.remarks = remarks; }
	 * 
	 * public String getCategory() { return category; }
	 * 
	 * public void setCategory(String category) { this.category = category; }
	 * 
	 * public String getType() { return type; }
	 * 
	 * public void setType(String type) { this.type = type; }
	 */

	

}
