package com.iiht.dao;

import java.util.Map;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.iiht.exception.ResourceNotFoundException;
import com.iiht.model.User;
import com.iiht.model.Skill;

@Repository("userDao")
@Transactional(propagation= Propagation.REQUIRED)
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public boolean saveUser(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	public Map<User, Skill> searchByUserName(String name) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean userAllotment(String movie) {
		// TODO Auto-generated method stub
		return false;
	}

}
