package com.iiht.service;

import java.util.Map;

import com.iiht.exception.ResourceNotFoundException;
import com.iiht.model.User;
import com.iiht.model.Skill;

public interface UserService {

	public boolean saveUser(User user);
	public Map<User,Skill> searchByUserName(String name) throws ResourceNotFoundException;
	public boolean userAllotment(String user);
}
