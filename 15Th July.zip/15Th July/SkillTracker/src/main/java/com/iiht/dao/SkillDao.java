package com.iiht.dao;

import java.util.Map;

import com.iiht.model.User;
import com.iiht.model.Skill;

public interface SkillDao {

	public boolean saveSkill(Skill skill);
	public Map<Skill,User> searchBySkillName(String name);
	public Map<Skill,User> searchByEmail(String email);
	public Map<Skill,User> searchByMobile(String mobile);
}
