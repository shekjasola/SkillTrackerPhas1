package com.iiht.dao;

import java.util.Map;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.iiht.model.User;
import com.iiht.model.Skill;

@Repository("skillDao")
@Transactional(propagation= Propagation.REQUIRED)
public class SkillDaoImpl implements SkillDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public boolean saveSkill(Skill skill) {
		// TODO Auto-generated method stub
		return false;
	}

	public Map<Skill, User> searchBySkillName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public Map<Skill, User> searchByMobile(String mobile) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public Map<Skill, User> searchByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}
}
