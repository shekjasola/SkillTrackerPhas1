package com.iiht.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.iiht.model.Skill;
import com.iiht.service.SkillService;

@Controller
public class SkillController {

	@Autowired
	private SkillService skillService;
	
	@RequestMapping("/addskill")
	public ModelAndView addNewSkill(){
		return null;
	}
	
	@RequestMapping(value="/saveskill",method = RequestMethod.POST)
	public ModelAndView addMultiplex(@ModelAttribute("skill") Skill multiplex){
		return null;
	}
		
	@RequestMapping("/viewskill")
	public ModelAndView searchByMultiplex(){
		return null;
	}
	
}
