package com.iiht.exceptioncases;
import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.iiht.exception.ResourceNotFoundException;
import com.iiht.model.User;
import com.iiht.model.Skill;
import com.iiht.service.UserServiceImpl;
import com.iiht.service.SkillServiceImpl;

public class ExceptionTest {

	
}
